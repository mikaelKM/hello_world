<?php include("header.php");?>
<style type="text/css">
    .table{
        border:0px;
        width: 100%;
        
    }
    .img-responsive{
        width: 50px;
    height:50px;
    
    }
    h3{
        font-family: times;
        color: purple;
    
    }
    tbody{
        background: lightblue;
    }
    thead{
        background: purple;
        color: white;
    }
  </style>
  <body>
<?php
 if (isset($_GET['pageno'])){
   $pageno=$_GET['pageno'];
 } else {
   $pageno=1;
 }
 $no_of_records_per_page=6;
 $offset=($pageno-1)*$no_of_records_per_page;
 
 include ("connection.php");
 echo "<section id='team' class='pb-5'><div class='container'>";
 echo "
<h3>GOODS SOLD</h3></div>
                           
                            <div class='table-responsive'>
    <table class='table table-bordered'>
    <thead>
    <tr>
    <th>USERNAME</th>
    <th>FIRST NAME</th>
    <th>LAST NAME</th>
    <th>GOOD</th>
    <th>IMAGE</th>
   
    <th>PRICE</th>
    <th>MODE OF PAYMENT</th>
    <th>CUSTOMER LOCATION</th>
    <th>CUSTOMER CONTACT</th>
    <th>CUSTOMER EMAIL</th>
    <th>DELIVERY TIME</th>
    </tr> 
    <thead>";
 $total_pages_sql="SELECT COUNT(*) FROM SoldGoods";
 $result = mysqli_query($con,$total_pages_sql);
 $total_rows=mysqli_fetch_array($result)[0];
 $total_pages=ceil($total_rows / $no_of_records_per_page);

 $sql="SELECT* FROM SoldGoods LIMIT $offset,$no_of_records_per_page";
 $res_data= mysqli_query($con,$sql);
 while($row= mysqli_fetch_array($res_data)){
 	$username = $row["username"];
$Fname = $row["Fname"];
$Lname = $row["Lname"];
$good = $row["good"];
$image = $row["image"];

$price = $row["price"];
$mode = $row["mode of payment"];
$CustomerLocation = $row["CustomerLocation"];
$customer_contact = $row["customer_contact"];
$customer_email = $row["customer_email"];
$delivery_time = $row["delivery_time"];

        echo "<tbody>
 <tr>
    <td>".$username."</td>
    <td>".$Fname."</td>
    <td>".$Lname."</td>
    <td>".$good."</td>
    <td><img src=".$image." class='img-responsive'></td>
    
    <td>".$price."</td>
    <td>".$mode."</td>
    <td>".$CustomerLocation."</td>
    <td>".$customer_contact."</td>
    <td>".$customer_email."</td>
    <td>".$delivery_time."</td>
    </tr>
</tbody>";
  //echo "<tr><td>".$row['id']."</td><td>".$row['username']."</td><td>".$row['email']."</td></tr>";
  
 }
 echo "</table>";
 mysqli_close($con);
 ?>


	<div>
<nav aria-label="...">
 <ul class="pagination justify-content-center">
   <li><a href="?pageno=1">First</a></li>

   <li class="<?php if ($pageno<=1) {echo'disabled';}?>">
   <a href="<?php if ($pageno<=1){echo '#';} else {echo "?pageno=".($pageno-1);}?>">Prev</a>
</li>
<li class="<?php if ($pageno>=total_pages){echo 'disabled';}?>">
<a href="<?php if ($pageno>=$total_pages){echo '#';} else{echo"?pageno=".($pageno+1);}?>">Next</a>
</li>
<li><a href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
</ul>
</nav>
</div>
</div>

</section>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<?php include("fmkfooter.php");?>
</html>
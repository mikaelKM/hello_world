<?php
include('connection.php');
$bill=$_GET['price'];
$no=$_POST['phone'];
$sql="SELECT `Tell_no`, `Amount` FROM `mpesa` WHERE Tell_no='".$no."'";
//$sql "SELECT * FROM `mpesa` WHERE `Tell_no`='".$no."'";
$result=$con->query($sql);
if($result->num_rows>0){
					$row=$result->fetch_assoc();					
                      $amount=$row['Amount'];
						if($amount==0){
							echo "<script> alert('you account balance is zero');</script>";

							include('customer_site.php');
						}else{
							$balance=$amount-$bill;
							if($balance<0){
								echo "<script> alert('insufficient balance');</script>";
                               include('customer_site.php');
							}else{
								$sql1="UPDATE `mpesa` SET `Amount`=$balance WHERE Tell_no='".$no."'";
								$result1=$con->query($sql1);
                                if($result1==True){
                                	echo"<script> alert('you have paid  ".$bill."  to FMK Sales LMTD you account balance is  ".$balance."');</script>";
                                	//Echo"Here are your Bookings";
                                   include('payOnDel.php');	
                                 }else{
                                  	echo"payment request failed ";
	                              include('customer_site.php');
                                
							      }  }
						}
					}else {
						echo "<script> alert('you do not have an account')</script>";
					}
?>
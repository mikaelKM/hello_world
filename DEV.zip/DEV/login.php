 <?php  
session_start();
if(isset($_SESSION["username"]))
{
 header("location:customer_site.php");
}
$connect = mysqli_connect("localhost", "root", "", "fmk");  
if(isset($_POST["login"]))   
{  
 if(!empty($_POST["member_name"]) && !empty($_POST["member_password"]))
 {
  $name = mysqli_real_escape_string($connect, $_POST["member_name"]);

  $password = md5(mysqli_real_escape_string($connect, $_POST["member_password"]));

  $sql = "Select * from customers where username = '" . $name . "' and pass = '" . $password . "'";  

  $result = mysqli_query($connect,$sql);  
  $user = mysqli_fetch_array($result);  

  if($user)   
  {  
   if(!empty($_POST["remember"]))   
   {  
    setcookie ("member_login",$name,time()+ (10 * 365 * 24 * 60 * 60));  
    setcookie ("member_password",$_POST["member_password"],time()+ (10 * 365 * 24 * 60 * 60));
    $_SESSION["admin_name"] = $name;
   }  
   else  
   {  
    if(isset($_COOKIE["member_login"]))   
    {  
     setcookie ("member_login","");  
    }  
    if(isset($_COOKIE["member_password"]))   
    {  
     setcookie ("member_password","");  
    }  
   }  
   $_SESSION["username"] = $name;
   header("location:customer_site.php"); 
  }  
  else  
  {  
   $message = "Invalid Login";  
  } 
 }
 else
 {
  $message = "Both are Required Fields";
 }
}  
 ?>  
 
<html>  
 <head>  
  <title>LOG IN</title>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <<?//php include("header.php"); ?>
  <style> 

@import url("styling.css");

  
  </style>  
 </head>  
 <body>  
  <div class="container box">  
    <div class="juu">
    <h2>Login</h2>
  </div>
   <form class="formss" action="" method="post" id="frmLogin"> 
    

    <div class="text-danger"><?php if(isset($message)) { echo $message; } ?></div>  
    <div class="form-group">  
     <label for="login">Username</label>  
     <input name="member_name" type="text" value="<?php if(isset($_COOKIE["member_login"])) { echo $_COOKIE["member_login"]; } ?>" class="form-control" />  
    </div>  
    <div class="form-group">  
     <label for="password">Password</label>  
     <input name="member_password" type="password" value="<?php if(isset($_COOKIE["member_password"])) { echo $_COOKIE["member_password"]; } ?>" class="form-control" />   
    </div>  
    <div class="form-group">  
     <input type="checkbox" name="remember" id="remember_me"<?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />  
     <label for="remember_me">Remember me</label>  
    </div>  
    <div class="form-group">  
     <div><input type="submit" name="login" value="Login" class="btn btn-success"></span></div>  
    </div>   
   </form>  
   <br />  
  </div>  
 </body>  
</html>





<div class="mapouter"><div class="gmap_canvas"><iframe width="600" height="500" id="gmap_canvas" src="https://maps.google.com/maps?q=university%20of%20san%20francisco&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>Google Maps Generator by <a href="https://www.embedgooglemap.net">embedgooglemap.net</a></div><style>.mapouter{position:relative;text-align:right;height:500px;width:600px;}.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:600px;}</style></div>


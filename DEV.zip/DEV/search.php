<?php include("header.php");?>
<?php

if (isset($_POST["search"])){
include("connection.php");
    $query = $_POST['query'];
    
     
    $min_length = 1;
    
     
    if(strlen($query) >= $min_length){ 
         
        $query = htmlspecialchars($query);

        // changes characters used in html to their equivalents, for example: < to &gt;
         
        $query = mysqli_real_escape_string($con,$query);
         
        $raw_results = mysqli_query($con,"SELECT * FROM `general`
            WHERE (`name` LIKE '%".$query."%') OR (`category` LIKE '%".$query."%')") or die(mysql_error());
        
        echo  "<section id='team' class='pb-5'>
    
        <form action='pagination.php' method='post'>
       <div class='form-group'> <button class='btn -btn-primary' name='see_less' value='general'>SEE LESS</button></div>
       </form>
       <form action='no_pag.php' method='post'>
       <div class='form-group'>
      <input type='text' classs='form-control' name='search' placeholder='Number of items per page' required>
      
        <button class='btn btn-secondary' name='Search'>
         Search
          </button>
          </div>
          </div>
          </form>
          <div class='container'>
            <h5 class='section-title h1'>Here are the goods we offer</h5>
            <div class='row'> ";
        if(mysqli_num_rows($raw_results) > 0){ 
             
            while($results = mysqli_fetch_array($raw_results)){
           
            $name=$results['name']; 
            $image=$results['image']; 
            $description=$results['description'];
            $price=$results['price'];
            $category=$results['category'];
            echo "<div class='col-xs-12 col-sm-6 col-md-4'>
            <div class='image-flip' ontouchstart='this.classList.toggle('hover');'>
                <div class='mainflip'>
                    <div class='frontside'>
                        <div class='card'>
                            <div class='card-body text-center'>
                            <h4 class='card-header'>".$category."</h4>
                                <p><img class='img-fluid' src=".$image." alt=".$name."></p>
                                <h4 class='card-title'>".$name."</h4>
                                <p class='card-text'>".$description."</p>
                                
                            </div>
                        </div>
                    </div>
                    <div class='backside'>
                        <div class='card'>
                            <div class='card-body text-center mt-4'>
                                <h4 class='card-title'>".$name."</h4>
                                <p class='card-text'>".$description.'<br> Price: Ksh '.$price."</p>
                                <a href='buy.php?buy=".$name."' class='btn btn-primary'>BUY GOOD</a>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>";
             
            }
           
        }
        else{ 
            echo "No results";
        }
         
    }
    else{ 
        echo "Minimum length is ".$min_length;
  }  
  echo " </div>
  </div>
</section>";
}
?>
<?php include("fmkfooter.php");?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
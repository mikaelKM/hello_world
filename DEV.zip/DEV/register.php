
<!DOCTYPE html>
<html>
<head>
  <title>sign up</title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <?php include("header.php"); ?>
  <style>
@import url("styling.css");
  </style>
</head>
<body style="background:violet;">
  <div class="juu">
  	<h2>Register</h2>
  </div>

  <form class="formss" method="post" action="Through_db.php">
  	<div class="form-group">
  	  <label>Username</label>
  	  <input type="text" name="username"  placeholder="username" required>
	  </div>
	  <div class="form-group">
  	  <label>First Name</label>
  	  <input type="text" name="fname"  placeholder="First Name" required>
	  </div>
	  <div class="form-group">
  	  <label>Last Name</label>
  	  <input type="text" name="lname"  placeholder="Last Name" required>
  	</div>
  	<div class="form-group">
  	  <label>Email</label>
  	  <input type="email" name="email"  placeholder="example@email.com" required>
	  </div>
	  <div class="form-group">
  	  <label>Phone number</label>
  	  <input type="number" name="phone"  placeholder="" required>
  	</div>
  	<div class="form-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1" required>
  	</div>
  	<div class="form-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2" required>
  	</div>
<!--  <div class="form-group">
      <div class="avatar"><lable>select your picture:</lable><input type="file" name="avatar" accept"image/*"></div>-->
  	  <button type="submit" class="btn btn-primary" name="reg_user">Register</button>
  </div>
  	<p>
  		Already a member? <a href="login.php">Log in</a>
  	</p>
  </form>
 
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
<?php include("fmkfooter.php"); ?>
</html>

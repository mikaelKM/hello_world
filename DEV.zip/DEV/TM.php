
<!DOCTYPE html>
<html>
<head>
	<title>Customer Site</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <?php
     include("header.php");
      ?>
      <style>
        @import url("goods.css");
        </style>
</head>
<body style="background:#eee;">
<?php 

include ("connection.php");

$sql5 = "SELECT * FROM `general` WHERE category='TVs and Music Systems'";

$result5 = $con->query($sql5);


if ($result5->num_rows>0){

    
    echo  "<section id='team' class='pb-5'>
    <div class='container'>
        <h5 class='section-title h1'>Welcome to our Tvs and Music Systems mall</h5>
        <div class='row'>";
   
   while($row = $result5->fetch_assoc()) {
        $name=$row['name']; 
        $image=$row['image']; 
        $description=$row['description'];
        $price=$row['price'];
/*
$_SESSION["name"]= $name;
        $_SESSION["image"]= $image;
        $_SESSION["description"]= $description;
        $_SESSION["price"]= $price;
    
$_SESSION['goods']=array();
array_push($_SESSION['goods'], $name, $image, $description, $price);
*/
  echo "<div class='col-xs-12 col-sm-6 col-md-4'>
                <div class='image-flip' ontouchstart='this.classList.toggle('hover');'>
                    <div class='mainflip'>
                        <div class='frontside'>
                            <div class='card'>
                                <div class='card-body text-center'>
                                    <p><img class='img-fluid' src=".$image." alt=".$name."></p>
                                    <h4 class='card-title'>".$name."</h4>
                                    <p class='card-text'>".$description."</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class='backside'>
                            <div class='card'>
                                <div class='card-body text-center mt-4'>
                                    <h4 class='card-title'>".$name."</h4>
                                    <p class='card-text'>".$description.'<br>Price: kSH '.$price."</p>
                                    <a href='buy.php?buy=".$name."' class='btn btn-primary'>BUY GOOD</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div> ";
            
    
}
    $result5->free();
    echo " </div>
            </div>
        </section>";
} else {
    echo "<h5 class='section-title h1'>Welcome to our TVs and Music Systems  mall. <br> Currently we have run out of stock in this category</h5>";
}
$con->close();
?>




<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
<?php include("fmkfooter.php"); ?>
    </html>

<?php 

include ("connection.php");

$sql3 = "SELECT * FROM `general`";
$result3 = $con->query($sql3);

if ($result3->num_rows>0){

    
    echo  "<section id='team' class='pb-5'>
    
    <form action='pagination.php' method='post'>
   <div class='form-group'> <button class='btn -btn-primary' name='see_less' value='general'>SEE LESS</button></div>
   </form>
   <!--<form action='no_pag.php' method='post'>
   <div class='form-group'>
  <input type='text' classs='form-control' name='search' placeholder='Number of items per page' required>
  
    <button class='btn btn-secondary' name='Search'>
     Search
      </button>
      </div>
      </div>
      </form>-->
      <div class='container'>
        <h5 class='section-title h1'>Here are the goods we offer</h5>
        <div class='row'> ";
   
   while($row = $result3->fetch_assoc()) {
       
        $name=$row['name']; 
        $image=$row['image']; 
        $description=$row['description'];
        $price=$row['price'];
        $category=$row['category'];

      /*
        $_SESSION["name"]= $name;
        $_SESSION["image"]= $image;
        $_SESSION["description"]= $description;
        $_SESSION["price"]= $price;
        $_SESSION["category"]= $category;

        $_SESSION['goods']=array();
array_push($_SESSION['goods'], $name, $image, $description, $price);
        */
$im = "image/".$image;
  echo "<div class='col-xs-12 col-sm-6 col-md-4'>
                <div class='image-flip' ontouchstart='this.classList.toggle('hover');'>
                    <div class='mainflip'>
                        <div class='frontside'>
                            <div class='card'>
                                <div class='card-body text-center'>
                                <h4 class='card-header'>".$category."</h4>
                                    <p><img class='img-fluid' src=".$image." alt=".$name."></p>
                                    <h4 class='card-title'>".$name."</h4>
                                    <p class='card-text'>".$description."</p>
                                    
                                </div>
                            </div>
                        </div>
                        <div class='backside'>
                            <div class='card'>
                                <div class='card-body text-center mt-4'>
                                    <h4 class='card-title'>".$name."</h4>
                                    <p class='card-text'>".$description.'<br> Price: Ksh '.$price."</p>
                                    <a href='buy.php?buy=".$name."' class='btn btn-primary'>BUY GOOD</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>";
}
    $result3->free();
    echo " </div>
            </div>
        </section>";
} else {
    echo "no goods currently in";
}
$con->close();
?>


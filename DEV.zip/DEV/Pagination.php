<?php
  include("header.php");
  
 echo "<section id='team' class='pb-5'>
 <div class='container'> <h5 class='section-title h1'>Here are the goods we offer</h5>
  <div class='row'> ";
 // if (isset($_POST["see_less"])){

 if (isset($_GET['pageno'])){
   $pageno = $_GET['pageno'];
 } else {
   $pageno=1;
 }
 $no_of_records_per_page=6;
 $offset=($pageno-1)*$no_of_records_per_page;
include("connection.php");
 if(mysqli_connect_error()){
   echo "failed to connect to MySQL".mysqli_connect_error();
   die();
 }

 $see_less = "general";
 $total_pages_sql="SELECT COUNT(*) FROM `$see_less`";
 $result = mysqli_query($con,$total_pages_sql);
 $total_rows = mysqli_fetch_array($result)[0];
 $total_pages=ceil($total_rows / $no_of_records_per_page);

 $sql="SELECT* FROM `$see_less` LIMIT $offset,$no_of_records_per_page";
 $res_data= mysqli_query($con,$sql);
 while($row= mysqli_fetch_array($res_data)){
    $name=$row['name']; 
    $image=$row['image']; 
    $description=$row['description'];
    $price=$row['price'];
    $category=$row['category'];

    echo "<div class='col-xs-12 col-sm-6 col-md-4'>
    <div class='image-flip' ontouchstart='this.classList.toggle('hover');'>
        <div class='mainflip'>
            <div class='frontside'>
                <div class='card'>
                    <div class='card-body text-center'>
                    <h4 class='card-header'>".$category."</h4>
                        <p><img class='img-fluid' src=".$image." alt=".$name."></p>
                        <h4 class='card-title'>".$name."</h4>
                        <p class='card-text'>".$description."</p>
                        
                    </div>
                </div>
            </div>
            <div class='backside'>
                <div class='card'>
                    <div class='card-body text-center mt-4'>
                        <h4 class='card-title'>".$name."</h4>
                        <p class='card-text'>".$description.'<br> Price: Ksh '.$price."</p>
                        <a href='#' class='btn btn-primary'>BUY GOOD</a>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>";
    
  //echo "<tr><td>".$row['id']."</td><td>".$row['username']."</td><td>".$row['email']."</td></tr>";
  
 }
 mysqli_close($con);
 // }
?>

</div>
<nav style="align:bottom;">
 <ul class="pagination">
   <li><a href="?pageno=1">First</a></li>
   <li class="<?php if ($pageno <= 1) {echo 'disabled';}?>">
   <a href="<?php if ($pageno <= 1){echo '#';} else {echo "?pageno=".($pageno - 1);}?>">Prev</a>
</li>
<li class="<?php if ($pageno >= $total_pages){echo 'disabled';} ?>">
<a href="<?php if ($pageno >= $total_pages){echo '#';} else{echo "?pageno=".($pageno + 1); }?>">Next</a>
</li>
<li><a href="?pageno = <?php echo $total_pages; ?>">Last</a></li>
</ul>
</nav> 
</div>
           
        </section>
</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<?php include("fmkfooter.php");?>
</html>



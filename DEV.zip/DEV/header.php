<?php 
session_start();
?>
<html>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style type="text/css">
   @import url(project.css);
   @import url(goods.css);
    </style>


    <header>
       <div class="container">
          <img src="image/fmk.png" alt="logo" class="logo" >
           <nav>
               <ul>
               <li>
                <form action="search.php" method="POST"><div class="input-group">
  <input type="text" class="form-control" name="query" placeholder="search" required>
  <div class="input-group-append">
    <button class="btn btn-secondary" type="submit" name="search" style="background-size: 40px 40px;background-repeat: no-repeat;">
      <i class="fa fa-search"></i>
</button>
</div>
</div></form></li>
               
                   <li><div class="btn-group"><a href="index.php"><button class="btn btn-secondary" type="button" class="link">HOME</button></a></li>
                  
                   <li> <div class="btn-group dropright">
                       <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">CATEGORIES</button>
                     <div class="dropdown-menu" >
                      <a class="dropdown-item" href="ST.php">SMARTPHONES AND TABLETS</a>
                   <a class="dropdown-item" href="LD.php">LAPTOPS AND DESKTOPS</a>
                   <a class="dropdown-item" href="TM.php">TVS AND MUSIC SYSTEM</a>
                   <a class="dropdown-item" href="CF.php">CLOTHING AND FASHION</a>
                   
                   <a class="dropdown-item" href="AM.php">MOTORS AND AUTOMOBILE</a>
                   
</div>

</div></li>
                   <li>
                     <div class="dropdown">
                       <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">USERS</button>
                   <div class="dropdown-menu" aria-labelledby="dopdownMenuButton">
                    
                  <a class="dropdown-item" href="check.php">CUSTOMER</a>
                    <a class="dropdown-item" href="log.php">SUPPLIER</a>
                  <a class="dropdown-item" href="admin_site.php">ADMIN</a>
</div>
</div>
                  </li>
                   <li>
                    


<?php 
/*if($_SESSION['username'])
{ ?>

    <ul class="ts-profile-nav">
      <li class="ts-account">
        <a href="#"><img src="img/ts-avatar.jpg" class="ts-avatar hidden-side" alt=""> Account <i class="fa fa-angle-down hidden-side"></i></a>
        <ul>
          <li><a href="my-profile.php">My Account</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </li>
    </ul>
  
<?php
} else { ?>

<a href=login.php><button type='button' class='btn btn-primary'>LOG IN</button></a>
  <?php } */?>
  <?php

if(empty($_SESSION['username'])){
  echo "<a href=login.php><button type='button' class='btn btn-primary'>LOG IN</button></a>";
}else{
  echo "<a href=destroy.php><button type='button' class='btn btn-primary'>".$_SESSION['username']."<br>LOG OUT</button></a>";
}
  ?>

    </li>
                   <li></li>
</ul>
</nav>
</header>


<script>
   $(document).ready(function () {
   
  $(".ts-sidebar-menu li a").each(function () {
    if ($(this).next().length > 0) {
      $(this).addClass("parent");
    };
  })
  var menux = $('.ts-sidebar-menu li a.parent');
  $('<div class="more"><i class="fa fa-angle-down"></i></div>').insertBefore(menux);
  $('.more').click(function () {
    $(this).parent('li').toggleClass('open');
  });
  $('.parent').click(function (e) {
    e.preventDefault();
    $(this).parent('li').toggleClass('open');
  });
  $('.menu-btn').click(function () {
    $('nav.ts-sidebar').toggleClass('menu-open');
  });
   
   
   $('#zctb').DataTable();
   
   
   $("#input-43").fileinput({
    showPreview: false,
    allowedFileExtensions: ["zip", "rar", "gz", "tgz"],
    elErrorContainer: "#errorBlock43"
      // you can configure `msgErrorClass` and `msgInvalidFileExtension` as well
  });

 });

</script>
<style>
    @import url("styling.css");
 
  </style>
</head>
<body style="background: lightgreen;";>
  <div class="juu">
  	<h2>Login</h2>
  </div>

  <form class="formss" method="post" action="Through_db.php">
  	
  	<div class="form-group">
  		<label>Username</label>
  		<input type="text" name="username" required >
  	</div>
  	<div class="form-group">
  		<label>Password</label>
  		<input type="password" name="password" required>
  	</div>
  	<div class="form-group">
  		<button type="submit" class="btn btn-primary" name="login_userr">Login</button>
  	</div>
  	<p>
  		Not yet a member... <a href="registerfirst.php">Sign up</a>
  	</p>
	</form>
<style>
    @import url("styling.css");
    </style>
   <!--User registration-->
<?php 

require("connection.php");
if (isset($_POST["reg_user"])){
    $username = $_POST["username"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
	$password_1 = $_POST["password_1"];
	$password_2 = $_POST["password_2"];
  
$sq = "SELECT * FROM `customers`  WHERE username='$username";
$res = $con->query($sq);
$num_rows = mysqli_num_rows($res);
    if ($num_rows>0){
      echo "USERNAME TAKEN";
    }

$sq1 = "SELECT * FROM `customers`  WHERE email='$email";
$res1 = $con->query($sq1);
$num_rows = mysqli_num_rows($res1);
    if ($num_rows>0){
      echo "EMAIL TAKEN";
    }





if ($password_1 != $password_2){

  header("Location: register.php");
 $errorMessage =  "Passwords mismatch";     
  echo "<div class='error'>".$errorMessage."</div>";
    
}
else{
$passw1 = md5($password_1);

    $sql = "INSERT INTO `customers` (`username`, `Fname`, `Lname`, `email`, `phone`, `pass`, `image`) VALUES ('$username', '$fname', '$lname', '$email', '$phone', '$passw1', 'NULL')";
$result = $con->query($sql);
if($result === TRUE){
	$Message =  "Successful Registration";
    echo "<div class='sucess'>$Message</div>";
	session_start();
    $_SESSION['username'] = $username;
    $_SESSION['success'] = "Registration is successful";
header("Location: login.php");

}else{
    
    echo "<div class='error'>. $sql.$con->error</div>";
}
}
$con->close();
}
  ?>
     <!--User registration first-->
<?php 

require("connection.php");
if (isset($_POST["reg_userr"])){
    $username = $_POST["username"];
    $fname = $_POST["fname"];
    $lname = $_POST["lname"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
  $password_1 = $_POST["password_1"];
  $password_2 = $_POST["password_2"];

$sq = "SELECT * FROM `customers`  WHERE username='$username";
$res = $con->query($sq);
$num_rows = mysqli_num_rows($res);
    if ($num_rows>0){
      echo "USERNAME TAKEN";
    }

$sq1 = "SELECT * FROM `customers`  WHERE email='$email";
$res1 = $con->query($sq1);
$num_rows = mysqli_num_rows($res1);
    if ($num_rows>0){
      echo "EMAIL TAKEN";
    }



if ($password_1 != $password_2){

  header("Location: register.php");
 $errorMessage =  "Passwords mismatch";     
  echo "<div class='error'>$errorMessage</div>";
    
}else{
$passw1 = md5($password_1);

    $sql = "INSERT INTO `customers` (`username`, `Fname`, `Lname`, `email`, `phone`, `pass`, `image`) VALUES ('$username', '$fname', '$lname', '$email', '$phone', '$passw1', 'NULL')";
$result = $con->query($sql);
if($result === TRUE){
  $Message =  "Successful Registration";
    echo "<div class='sucess'>$Message</div>";
  session_start();
    $_SESSION['username'] = $username;
    $_SESSION['success'] = "Registration is successful";
header("Location: buy.php");

}else{
    
    echo "<div class='error'>. $sql.$con->error</div>";
}
}
$con->close();
}
  ?>
<!-- user log in-->

  <?php 
  if (!empty($_SESSION['username'])){
    $errorMessage =  "you are already logged in as ".$_SESSION["username"];
    echo "<div class='sucess'>$errorMessage</div>";
    
    header("Location: customer_site.php");
    
  }else{
  if (isset($_POST["login_user"])){
      $usern = $_POST["username"];
      $passd = md5($_POST["password"]);
    include ("connection.php");
    $sql= "SELECT * FROM `customers`  WHERE username='$usern' AND pass='$passd'";
    $result =$con->query($sql);
    $num_rows = mysqli_num_rows($result);
    if ($num_rows>0){

    session_start();
    $_SESSION['username'] = $usern;
    
  	$_SESSION['success'] = "Successfully logged in";
    header("Location: customer_site.php");
    }
    else
    {
        $errors = array();
    $errorMessage =  "you have entered wrong credentials";
    echo "<div class='error'>$errorMessage</div>";
    
 include("login.php");
    
    }
    }
}
  ?>
  <!-- log in to buy-->
  <?php 
  if (isset($_POST["login_userr"])){
      $usern = $_POST["username"];
      $passd = md5($_POST["password"]);
    include ("connection.php");
    $sql= "SELECT * FROM `customers`  WHERE username='$usern' AND pass='$passd'";
    $result =$con->query($sql);
    $num_rows = mysqli_num_rows($result);
    if ($num_rows>0){
      
    session_start();
    $_SESSION['username'] = $usern;
    
    $_SESSION['success'] = "Successfully logged in";
    header("Location: buy.php");
    }
    else
    {
        $errors = array();
    $errorMessage =  "you have entered wrong credentials";
    echo "<div class='error'>$errorMessage</div>";
    
 include("buy.php");
    
    }
    }
  ?>
<!-- supplier posting goods to the database -->
  <?php 

if (isset($_POST["send_db"])){
   $name = $_POST["name"];
   $quantiy = $_POST["quantity"];
   //$file = $_POST["pic"];
   $price = $_POST["price"];
   $description = $_POST["description"];
   $category = $_POST["category"];



if ($_FILES["pic"]["error"]>0){
  echo $_FILES['pic']['name']." As the following erors";

  switch ($_FILES['pic']['error']) {
    case 1:
      echo " file exceeded max upload size";
      break;
    case 2:
      echo " file exceed max file size";
        # code...
      break;
    case 3:
      echo " file only partially uploaded";
      # code...
      break;
    case 4:
      echo " no file to be uploaded";
      # code...
      break;
    default:
      echo " i dont understand what you want";
      # code...
      break;
  }
  exit();
}
$type = pathinfo(basename($_FILES["pic"]["name"]),PATHINFO_EXTENSION);
if ($type != "png" && $type != "jpeg" && $type != "jpg"){ // && $_FILES['pic']['type']!= "png" && $_FILES['pic']['type']!= "jpeg"
echo "Your image is not of the form jpg, png or jpeg";
exit();
}

$file = "image/".$_FILES['pic']['name'];

if(is_uploaded_file($_FILES['pic']['tmp_name'])){
  if(!move_uploaded_file($_FILES['pic']['tmp_name'], $file )){
    echo "problem in moving the file to the final directory";
}


}else{
  echo "A possible file upload attack for the file ".$_FILES['pic']['name'];
}
//echo "file uploaded successfully";
//exit();







   require("connection.php");
   $sql = "INSERT INTO `supplier_goods` (`name`, `amount`, `image`, `description`, `price`, `category`) VALUES ('$name', '$quantiy', '$file', '$description', '$price', '$category')";
$result = $con->query($sql);
if($result === TRUE){
    $Message =  "Successully added to database";
    echo "<div class='success'>$Message</div>";
    include("supplier_site.php");

}else{
    $errorMessage =  "an error encountered";
    echo "<div class='error'>$errorMessage  . $sql.$con->error </div>";
}
$con->close();
}
   ?>
<!-- supplier log in -->
<?php 
  if (isset($_POST["supplier_login"])){
      $usern = $_POST["name"];
      $passd = md5($_POST["password"]);
    include ("connection.php");
    $sql= "SELECT * FROM `suppliers`   WHERE username='$usern' AND password='$passd'";
    $result =$con->query($sql);
    $num_rows = mysqli_num_rows($result);
    if ($num_rows>0){
    session_start();
    $_SESSION['login'] = $usern;
    header("Location: supplier_site.php");
    }
    else
    {
        
    $errorMessage =  "you have entered wrong credentials";
    echo "<div class='error'>$errorMessage</div>";

    include("log.php");
    }
    }
  ?>
  <!--admin remove supplier-->
  <?php 
  if (isset($_POST["remove"])){
      $usernamee = $_POST["username"];
      include ("connection.php");
      
      $sql = "DELETE FROM `suppliers` WHERE username='$usernamee'";
      $result = $con->query($sql);
      if (!$result){
          echo "not successfully deleted " .$con->error;
      }else{
          echo "deletion successful";
      }
      $con->close();
  }
  ?>

<!--Adiing supplier to site-->

<?php 
  if (isset($_POST["add"])){
      $usernamee = $_POST["username"];
      $names = $_POST["names"];
      $email = $_POST["email"];
      $phone = $_POST["phone"];
      $password = md5($_POST["password"]);
      
      include ("connection.php");
      $sql = "INSERT INTO `suppliers` (`username`, `names`, `email`, `phone`, `password`) VALUES ('$usernamee', '$names', '$email', '$phone', '$password')";
      $result = $con->query($sql);
      if (!$result){
          echo "not successfully added to the database " .$con->error;
          $errorMessage =  "not successfully added to the database " .$con->error;
    echo "<div class='error'>$errorMessage</div>";
          
      }else{
         
          $errorMessage =  "Supplier successfully added";
    echo "<div class='success'>$errorMessage</div>";
      }
      $con->close();
  }
  ?>

  <!--approving goods to the site-->
  <?php 
  if(isset($_POST["approve"])){
      include("connection.php");
  
session_start();

$name =$_POST["name"];
 $image =$_POST["image"];
$description=$_POST["description"];
 $price= $_POST["price"];
 $category= $_POST["category"];
 $quantity=$_POST["amount"];
 
        $sql2 ="INSERT INTO `general` (`name`, `image`, `description`, `price`, `quantity`, `category`) VALUES ('$name', '$image', '$description', '$price', '$quantity', '$category')";

        $sql3 = "DELETE FROM `supplier_goods` WHERE name='$name'";
        
    $result=$con->query($sql2);
    if(!$result){
        echo "no changes made ".$con->error;
    }else{
      $result2 = $con->query($sql3);
        echo "Successfully added to DB";
        include("admin_site.php");
    }
    }
  
  ?>
  <!-- Disaaproving goods-->
  <?php 
  if (isset($_POST["disapprove"])){
      
      include("connection.php");
  
session_start();

$name =$_SESSION["name"];
 $image =$_SESSION["image"];
$description=$_SESSION["description"];
 $price= $_SESSION["price"];
 $category= $_SESSION["category"];
 $quantity=$_SESSION["amount"];
        
        $sql3 = "DELETE FROM `supplier_goods` WHERE name='$name'";
        
   $result2 = $con->query($sql3);
    if(!$result2){
        echo "good not successfully removed ".$con->error;
    }else{
      
        echo "successfully disapproved";
    }
    
  }
  ?>
  <!--Updating Supplier details-->
  <?php 
if (isset($_POST["update_sd"])){
      $usernamee = $_POST["username"];
      $names = $_POST["names"];
      $email = $_POST["email"];
      $phone = $_POST["phone"];
      $password = md5($_POST["password"]);
      
      include ("connection.php");
      $sql = "UPDATE `suppliers` SET `names`='$names',`email`='$email',`phone`='$phone',`password`='$password' WHERE username='$usernamee'";
      $result = $con->query($sql);
      if (!$result){
          $errorMessage =  "not successfully updated " .$con->error;
    echo "<div class='error'>$errorMessage</div>";
          
      }else{
         
          $errorMessage =  "Supplier details successfully updated";
    echo "<div class='success'>$errorMessage</div>";
      }
      $con->close();
  }
  ?>
<?php 
$user="root";
$pass="";
$db="fmk";

$con = MySqli_Connect('localhost',$user,$pass,$db); 
if ($con->connect_error){
    die ("no connection created: ". $con->connect_error);
}
?>
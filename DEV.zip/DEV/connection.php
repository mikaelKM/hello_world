<?php 
$user="MIKAEL";
$pass="mike00049ann";
$db="fmk";

$con = MySqli_Connect('localhost',$user,$pass,$db); 
if ($con->connect_error){
    die ("no connection created: ". $con->connect_error);
}
?>
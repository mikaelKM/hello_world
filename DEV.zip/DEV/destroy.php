<style>
.success {
  color: #3c763d;
  background: #dff0d8;
  border: 1px solid #3c763d;
  margin-bottom: 20px;

}
</style>
<?php
session_start();
?>
<?php 
session_unset(); 
session_destroy();

$Message =  "Successully logged out";
/*echo "<!-- Flexbox container for aligning the toasts -->
<div aria-live='polite' aria-atomic='true' class='d-flex justify-content-center align-items-center' style='min-height: 200px;'>

  <!-- Then put toasts within -->
  <div class='toast' role='alert' aria-live='assertive' aria-atomic='true'>
    <div class='toast-header>
      
      <strong class='mr-auto'>logged OUT</strong>
      
      <button type='button' class='ml-2 mb-1 close' data-dismiss='toast' aria-label='Close'>
        <span aria-hidden='true'>&times;</span>
      </button>
    </div>
    <div class='toast-body'>".
      $Message."
    </div>
  </div>
</div>";
*/
   echo "<div class='success'>$Message</div>";
include("index.php");
?>
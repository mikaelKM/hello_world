<style type="text/css">
    .table{
        border:0px;
        width: 50%;
        
    }
    .img-responsive{
        width: 50px;
    height:50px;
    
    }
    h3{
        font-family: times;
        color: purple;
    
    }
    tbody{
        background: lightblue;
    }
    thead{
        background: purple;
        color: white;
    }
</style>
<?php include("header.php");?>
<body>
    <?php 
include ("connection.php");

$sql3 = "SELECT * FROM `supplier_goods`";
$result3 = $con->query($sql3);

if ($result3->num_rows>0){

    
    echo  "<section id='team' class='pb-5'>
    <div class='container'>
        <h5 class='section-title h1'>Approve Or disapprove supplier goods</h5>
        <div class='row'>";
   
   while($row = $result3->fetch_assoc()) {
       

        $name=$row['name']; 
        $image=$row['image']; 
        $description=$row['description'];
        $price=$row['price'];
        $category=$row['category'];
        $quantity=$row['amount'];

        
        $_SESSION["name"]= $name;
        $_SESSION["image"]= $image;
        $_SESSION["description"]= $description;
        $_SESSION["price"]= $price;
        $_SESSION["category"]= $category;
        $_SESSION["amount"]= $quantity;
        
        $im = "image/".$image;
  echo "<div class='col-xs-12 col-sm-6 col-md-4'>
                <div class='card border-success mb-3' style='max-width: auto;'>
                <form action='Through_db.php' method='POST'>
                    <div class='card-header'><h4>".$category."</h4></div>
                                    <img class='img-fluid' src=".$image." alt=".$name.">
                                    <div class='card-body text-success'>
                                    <h4 class='card-title'>".$name."</h4>
                                    <p class='card-text'>".$description."</p>
                                    <p class='card-text'>Price: ".$price."</p>
                                    <p class='card-text'>Quantity: ".$quantity."</p>
                                    <form action='Through_db.php' method='POST'>
                                    <button class='btn btn-primary' name='approve' >APPROVE</button>
                                    <button class='btn btn-primary' name='disapprove'>DISAPPROVE</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    
                
                ";
}
    $result3->free();
    echo " </div>
            </div>
        </section>";
} else {
    echo "no goods currently in";
}
$con->close();
    ?>


    <section id='team' class='pb-5'>
    <div class='container'>
    <h3 class='section-title h1'>Update the supplier details</h3>
        <div class='row'>
    
    <div class='col-xs-12 col-sm-6 col-md-4'>
    <div class='card border-success mb-3' style='max-width: auto;'>
                    <div class='card-header'>Add supplier</div>
                    <div class='card-body'>
                                    <form action="Through_db.php" method="post" >
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" name="username" placeholder="username" required>
</div>
<div class="form-group">
                                            <label>Names: </label>
                                            <input type="text" class="form-control" name="names" placeholder="Firstname Lastname" required>
</div>
<div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="email" placeholder="Email" required>
</div>
<div class="form-group">
                                            <label>Phone Number</label>
                                            <input type="number" class="form-control" name="phone" placeholder="enter phone number" required>
</div>
<div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="password" required>
</div>
<div class="form-group">
                                    <button class='btn btn-primary' name='add'>ADD SUPPLIER</button>
</div>
</form>
                                </div>
                            </div>
                        </div>
                    


                    <div class='col-xs-12 col-sm-6 col-md-4'>
    <div class='card border-success mb-3' style='max-width: auto;'>
                    <div class='card-header'>Remove Supplier</div>
                    <div class='card-body'>
                                    <form action="Through_db.php" method="post">
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" name="username" placeholder="username" required>
</div>                 <div class="form-group">
                                    <button class='btn btn-primary' name='remove'>Remove SUPPLIER</button>
</div>
</form>
                                </div>
                            </div>
                        </div>
                        <div class='col-xs-12 col-sm-6 col-md-4'>
    <div class='card border-success mb-3' style='max-width: auto;'>
                    <div class='card-header'>UPdate Supplier Details</div>
                    <div class='card-body'>
                                    <form action="Through_db.php" method="post" >
                                        <div class="form-group">
                                            <label>Username</label>
                                            <input type="text" class="form-control" name="username" placeholder="username" required>
</div>
<div class="form-group">
                                            <label>Names: </label>
                                            <input type="text" class="form-control" name="names" placeholder="Firstname Lastname" required>
</div>
<div class="form-group">
                                            <label>Email</label>
                                            <input type="email" class="form-control" name="email" placeholder="Email" required>
</div>
<div class="form-group">
                                            <label>Phone Number</label>
                                            <input type="number" class="form-control" name="phone" placeholder="enter phone number" required>
</div>
<div class="form-group">
                                            <label>Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="password" required>
</div>
<div class="form-group">
                                    <button class='btn btn-primary' name='update_sd'>UPDATE</button>
</div>
</form>
                                </div>
                            </div>
                        </div>
                        </div> 

                    
<?php

include("connection.php");
$sql = "SELECT * FROM `SoldGoods`";
$result = $con->query($sql);
if ($result->num_rows>0){
echo "

<h3>GOODS SOLD</h3>
 <a href='see_less.php' class='btn btn-info'>SEE LESS</a> 
</div>
                         
                            <div class='table-responsive'>
    <table class='table table-bordered'>
    <thead>
    <tr>
    <th>USERNAME</th>
    <th>FIRST NAME</th>
    <th>LAST NAME</th>
    <th>GOOD</th>
    <th>IMAGE</th>
   
    <th>PRICE</th>
    <th>MODE OF PAYMENT</th>
    <th>CUSTOMER LOCATION</th>
    <th>CUSTOMER CONTACT</th>
    <th>CUSTOMER EMAIL</th>
    <th>DELIVERY TIME</th>
    </tr> 
    <thead>";

while($row = $result->fetch_assoc()){
$username = $row["username"];
$Fname = $row["Fname"];
$Lname = $row["Lname"];
$good = $row["good"];
$image = $row["image"];

$price = $row["price"];
$mode = $row["mode of payment"];
$CustomerLocation = $row["CustomerLocation"];
$customer_contact = $row["customer_contact"];
$customer_email = $row["customer_email"];
$delivery_time = $row["delivery_time"];

echo "<tbody>
 <tr>
    <td>".$username."</td>
    <td>".$Fname."</td>
    <td>".$Lname."</td>
    <td>".$good."</td>
    <td><img src=".$image." class='img-responsive'></td>
    
    <td>".$price."</td>
    <td>".$mode."</td>
    <td>".$CustomerLocation."</td>
    <td>".$customer_contact."</td>
    <td>".$customer_email."</td>
    <td>".$delivery_time."</td>
    </tr>
</tbody>";
    

  }
    $result->free();
    echo "</table>
    </div>
    ";
} else {
    echo "No Goods sold as at now";
}
$con->close();

 ?>
                   
            </div>
        </section>


</body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<?php include("fmkfooter.php");?>
</html>
<?php

require 'config.class.php';

/**
 * 
 */
class RetrieveRecords extends Config
{
	
	function __construct(argument)
	{
		parent::__construct();
	}


}
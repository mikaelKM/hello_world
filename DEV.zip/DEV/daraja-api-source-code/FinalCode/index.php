<?php

	// Leave this file here, it has its magic
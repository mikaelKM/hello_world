Hi,

This code is provided to you for free. I would appreciate
if you get it, give me a star on Github @bnjunge and I will
consider it a fair game :)


If you need any support on implementation I charge a small amount
so don't overwork yourself while we can fix it while you enjoy 
ice cream and watching your favourite movie :)

Any Help? Hit me up on 254716437799 or shoot an email to survtechke@gmail.com


Cheers,


##><###>
For the Love of Code

Ben.
ⓢⓤⓡⓥⓣⓔⓒⓗ ⓓⓐⓡⓐⓙⓐ ⓐⓟⓘ ⓣⓤⓣⓞⓡⓘⓐⓛ ⓒⓞⓓⓔ ⓥ①
<?php include("header.php");

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SUPPLIER SITE</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
h3{
            font-size: 40px;
            font-family:'Times New Roman', Times, serif;
            font-weight: 700;
            color: ;
        }
.btn-primary {
            border: none;
            outline: none;
            height: 40px;
            background: green;
            color: #fff;
            font-size: 18px;
            border-radius: 20px;
            padding: 10px;
            width: 48%;
        }
        .btn-danger {
            border: none;
            outline: none;
            height: 40px;
            color: #fff;
            font-size: 18px;
            border-radius: 20px;
            padding: 10px;
            width: 48%;
        }
    
</style>
</head>
<body style="background: url(image/ground.jpg);">
    <div class="container">
    <h3 class="text-center"> Hello Dear supplier, welcome to the best market for your goods. </h3>
    <h3 class="text-center"> Kindly enter the details of the goods your are selling bellow .</h3>
    <form action="Through_db.php" method="POST" enctype="multipart/form-data">
    <div class="form-group">
                        <label>Name of the good:</label>
                        <br>
                        <input type="text" name="name" class="form-control text" placeholder="goods name" required>
                    </div>
                    <div class="form-group">
                        <label>Quantity:</label>
                        <br>
                        <input type="number" name="quantity" class="form-control text" placeholder="quantity" required>
                    </div>
                    <div class="form-group">
                        <label>Good's Image:</label>
                        <br>
                        <input type="file" name="pic" class="form-control" accept="image">
                    </div>
                    <div class="form-group">
                        <label>price:</label>
                        <br>
                    
                        <input type="text" name="price" class="form-control text" placeholder="eneter price" required>
                    </div>
                    <div class="form-group">
  <label for="description">Item Description:</label>
  <textarea class="form-control" rows="5" id="description" name="description"></textarea>
</div>

                    <div class="form-group">
                        <label>Select the Category of goods:</label>
                        <select class="form-control text" name="category">
                            <option value="Smartphone and Tablates">Smartphone and Tablates</option>
                            <option value="Laptops and Desktops">Laptops and Desktops</option>
                            <option value="TVs and Music Systems">TVs and Music Systems</option>
                            <option value="Clothing and Fashion">Clothing and Fashion</option>
                            <option value="Motors and Automobile">Motors and Automobile</option>
                            
                        </select>
                    </div>
                    <br>
                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Submit" name="send_db">
                         <input type="reset" class="btn btn-danger" value="Reset">
                     </div>
                    <div class="form-group">
                        <a href="#">See the goods in stock instead</a>
                    </div>
                </form>
    
        
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
<?php include("fmkfooter.php"); ?>
</html>
<?php
session_start();
 if(empty($_SESSION['username'])){
    
    header("Location: login.php");
  }else{
    $errorMessage =  "you are already logged in as ".$_SESSION['username'];
    echo "<div class='sucess'>$errorMessage</div>";
    header("Location: customer_site.php");
  }
  ?>
-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2019 at 09:43 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmk`
--
CREATE DATABASE IF NOT EXISTS `fmk` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `fmk`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(90) NOT NULL,
  `password` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `automobile`
--

CREATE TABLE `automobile` (
  `name` varchar(6000) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `automobile`
--

INSERT INTO `automobile` (`name`, `image`, `description`, `price`) VALUES
('BMW Motorbike', 'hoda.png', 'BMW ridding bike\r\nenjoy exclussive speed\r\nhybrid engine\r\nmax speed 200kmph', '500000');

-- --------------------------------------------------------

--
-- Table structure for table `clothing`
--

CREATE TABLE `clothing` (
  `name` varchar(11) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clothing`
--

INSERT INTO `clothing` (`name`, `image`, `description`, `price`) VALUES
('dress', 'dress.png', 'the finest fo all body figures \r\nsize 32 ,circular, with wrist 28 \r\nfull description of what we call size-8\r\n', '1800');

-- --------------------------------------------------------

--
-- Table structure for table `computing`
--

CREATE TABLE `computing` (
  `name` varchar(6000) NOT NULL,
  `image` mediumtext NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computing`
--

INSERT INTO `computing` (`name`, `image`, `description`, `price`) VALUES
('MacBook', 'macbook.png', 'The best Macbook in our stores\r\n1TB hardDisk\r\n12Gb RAM\r\nTouchscreen enabled\r\nCorei7 3ghz microprocessor\r\nblack ', '250000');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `username` varchar(60) NOT NULL,
  `Fname` varchar(60) NOT NULL,
  `Lname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` int(20) NOT NULL,
  `pass` varchar(60000) NOT NULL,
  `image` varchar(633) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`username`, `Fname`, `Lname`, `email`, `phone`, `pass`, `image`) VALUES
('', '', '', '', 0, '', ''),
('mikael', 'mike', 'jagoo', 'mjk@gmail.com', 79885626, '6512bd43d9caa6e02c990b0a82652dca', 'NULL'),
('kelvin', 'joo', 'loonh', 'jk@hj.om', 78994, '6512bd43d9caa6e02c990b0a82652dca', 'NULL'),
('youid', 'hoiu', 'jjks', 'nmj@hou.mk', 789945, '35f4a8d465e6e1edc05f3d8ab658c551', 'NULL'),
('mike', 'mikael', 'mikaol', 'mike@gmail.com', 797753625, '18126e7bd3f84b3f3e4df094def5b7de', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('kkk', 'jdk', 'joel', 'mike@jkdk', 788, '', 'NULL'),
('uuuu', 'jkkk', 'yuh', 'sdfgh@3erfvb', 7885, '', 'NULL'),
('mikael', 'kasike', 'mike', 'mikaelkasike861@gmail.com', 797753625, '84dcd484d02ce383f781dd6804aac78e', 'NULL'),
('nash', 'nahashon', 'nnnnnnbn', 'a@gmail.com', 797753625, '81dc9bdb52d04dc20036dbd8313ed055', 'NULL'),
('Ann', 'mimbo', 'botellar', 'foo@jjj.koo', 7977513, '81dc9bdb52d04dc20036dbd8313ed055', 'NULL'),
('kelvin', 'kevo', 'yes', 'mikee@gmail.dk', 788898, '81dc9bdb52d04dc20036dbd8313ed055', 'NULL'),
('Mabo', 'Botela', 'Mikki', 'mikaalk@hjj.com', 76335946, '7da4639804c705fca86bbd989b7d5973', 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `entertainment`
--

CREATE TABLE `entertainment` (
  `name` varchar(6000) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entertainment`
--

INSERT INTO `entertainment` (`name`, `image`, `description`, `price`) VALUES
('Samsung TV', 'tv.png', 'The Best television in the world today\r\nHD televison\r\n32\'\' screen plasma display\r\n', '32000');

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE `general` (
  `name` varchar(60) NOT NULL,
  `image` varchar(60) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` int(25) NOT NULL,
  `quantity` int(25) NOT NULL,
  `category` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`name`, `image`, `description`, `price`, `quantity`, `category`) VALUES
('iphone', 'iphone8.png', 'The finest phone of your dream\r\nwith 4G network connection, good camera for selfies amoung others...\r\nGet one now!!\r\n', 17500, 1, 'smartphones and tablets'),
('iphone', 'iphone8.png', 'The finest phone of your dream\r\nwith 4G network connection, good camera for selfies amoung others...\r\nGet one now!!\r\n', 17500, 1, 'smartphones and tablets'),
('speedbike', 'download.jpg', 'cc 1500\r\nmodel 2017\r\nnew', 1000, 1, 'Motors and Automobile'),
('television', 'image/1 (6).jpg', 'enjoy football', 120000, 10, 'TVs and Music Systems'),
('food for work', 'image/aforestation-dirt-road-dusty-road-52599.jpg', 'intonessian greak food, eat and die', 15000, 36, 'Clothing and Fashion'),
('makasi', 'image/adventure-aerial-autumn-640809.jpg', 'hjjshbcbcb', 25000, 36, 'Clothing and Fashion'),
('makasi', 'image/adventure-aerial-autumn-640809.jpg', 'hjjshbcbcb', 25000, 36, 'Clothing and Fashion'),
('makasi', 'image/adventure-aerial-autumn-640809.jpg', 'hjjshbcbcb', 25000, 36, 'Clothing and Fashion');

-- --------------------------------------------------------

--
-- Table structure for table `smartphones and tablets`
--

CREATE TABLE `smartphones and tablets` (
  `name` varchar(600) NOT NULL,
  `image` varchar(600) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `smartphones and tablets`
--

INSERT INTO `smartphones and tablets` (`name`, `image`, `description`, `price`) VALUES
('Iphone', 'iphone8.png', 'The finest phone of your dream\r\n 4G network connection\r\n 13mp rear camera\r\n32 GB internal storage\r\n4GB RAM', '17500');

-- --------------------------------------------------------

--
-- Table structure for table `soldgoods`
--

CREATE TABLE `soldgoods` (
  `username` varchar(60) NOT NULL,
  `Fname` varchar(60) NOT NULL,
  `Lname` varchar(60) NOT NULL,
  `good` varchar(60) NOT NULL,
  `image` varchar(60) NOT NULL,
  `price` varchar(20) NOT NULL,
  `mode of payment` varchar(20) NOT NULL,
  `CustomerLocation` varchar(60) NOT NULL,
  `customer_contact` varchar(60) NOT NULL,
  `customer_email` varchar(60) NOT NULL,
  `delivery_time` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `soldgoods`
--

INSERT INTO `soldgoods` (`username`, `Fname`, `Lname`, `good`, `image`, `price`, `mode of payment`, `CustomerLocation`, `customer_contact`, `customer_email`, `delivery_time`) VALUES
('mike', 'mikael', 'kasike', 'iphone 8', 'image/iphone8.png', '85000', '', 'nakuru', '0797753625', 'mikaelkasike861@gmail.com', '333'),
('mike', 'mikael', 'kasike', 'iphone 8', 'image/iphone8.png', '85000', '', 'nakuru', '0797753625', 'mikaelkasike861@gmail.com', '333'),
('', 'mikael', 'mikaol', 'television', 'image/1 (6).jpg', '120000', '', 'Huruma', '07855', 'mike@gmail.com', '20-03-19 02:29:30pm'),
('mike', 'mikael', 'mikaol', 'television', 'image/1 (6).jpg', '120000', '', 'Huruma', '07855', 'mike@gmail.com', '20-03-19 02:30:14pm'),
('mike', 'mikael', 'mikaol', 'television', 'image/1 (6).jpg', '120000', '', 'Kasarani', '0797753625', 'mike@gmail.com', '20-03-19 02:32:45pm'),
('mike', 'mikael', 'mikaol', 'speedbike', 'download.jpg', '1000', 'Pay on delivery', 'Thika', '0710253621', 'mike@gmail.com', '20-03-19 02:44:22pm'),
('mike', 'mikael', 'mikaol', 'food for work', 'image/aforestation-dirt-road-dusty-road-52599.jpg', '15000', 'Pay on delivery', 'Pipeline', '07544251521', 'mike@gmail.com', '20-03-19 02:54:45pm'),
('mike', 'mikael', 'mikaol', 'iphone', 'iphone8.png', '17500', 'Pay on delivery', 'Huruma', '079885682154', 'mike@gmail.com', '20-03-19 06:23:40pm'),
('mike', 'mikael', 'mikaol', 'iphone', 'iphone8.png', '17500', 'Pay on delivery', 'Huruma', '079885682154', 'mike@gmail.com', '20-03-19 06:29:33pm'),
('mike', 'mikael', 'mikaol', 'makasi', 'image/adventure-aerial-autumn-640809.jpg', '25000', 'Pay on delivery', 'Huruma', '0797753625', 'mike@gmail.com', '21-03-19 11:12:40am'),
('mike', 'mikael', 'mikaol', 'makasi', 'image/adventure-aerial-autumn-640809.jpg', '25000', 'Pay on delivery', 'Huruma', '0797553625', 'mike@gmail.com', '21-03-19 12:29:42pm'),
('Mike', 'mikael', 'mikaol', 'makasi', 'image/adventure-aerial-autumn-640809.jpg', '25000', 'Pay on delivery', 'Kawagware', '0797753625', 'mike@gmail.com', '21-03-19 02:31:17pm'),
('mike', 'mikael', 'mikaol', 'makasi', 'image/adventure-aerial-autumn-640809.jpg', '25000', 'Pay on delivery', 'other', '0712358', 'mike@gmail.com', '21-03-19 07:27:33pm');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `username` varchar(60) NOT NULL,
  `names` varchar(600) NOT NULL,
  `email` varchar(600) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `password` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`username`, `names`, `email`, `phone`, `password`) VALUES
('kelvin', 'kasike', 'kasike@gmail.com', '078889', '81dc9bdb52d04dc20036dbd8313ed055'),
('mike', 'mikael kasike', 'mikaelkasike861@gmail.com', '0797753625', '84dcd484d02ce383f781dd6804aac78e');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_goods`
--

CREATE TABLE `supplier_goods` (
  `name` varchar(600) NOT NULL,
  `amount` int(11) NOT NULL,
  `image` varchar(600) NOT NULL,
  `description` longtext NOT NULL,
  `price` mediumtext NOT NULL,
  `category` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `uploadfile`
--

CREATE TABLE `uploadfile` (
  `filename` varchar(50) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploadfile`
--

INSERT INTO `uploadfile` (`filename`, `date`) VALUES
('up/receipt (8).txt', '0000-00-00 00:00:00.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

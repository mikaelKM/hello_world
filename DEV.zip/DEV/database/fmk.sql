-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2019 at 02:34 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fmk`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` varchar(90) NOT NULL,
  `password` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `automobile`
--

CREATE TABLE `automobile` (
  `name` varchar(6000) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `automobile`
--

INSERT INTO `automobile` (`name`, `image`, `description`, `price`) VALUES
('Buggati', '', 'The best car rooling around the world.\r\nenjoy superfast speeds.\r\n', '9000000'),
('Buggati', '', 'The best car rooling around the world.\r\nenjoy superfast speeds.\r\n', '9000000');

-- --------------------------------------------------------

--
-- Table structure for table `clothing`
--

CREATE TABLE `clothing` (
  `name` varchar(11) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(600) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clothing`
--

INSERT INTO `clothing` (`name`, `image`, `description`, `price`) VALUES
('Mens Suit', '', 'The best fitting for youths', '5,000'),
('Mens Suit', '', 'The best fitting for youths', '5,000');

-- --------------------------------------------------------

--
-- Table structure for table `computing`
--

CREATE TABLE `computing` (
  `name` varchar(6000) NOT NULL,
  `image` mediumtext NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `computing`
--

INSERT INTO `computing` (`name`, `image`, `description`, `price`) VALUES
('macbook pro', 'image/1(2).jpg', 'the generic macbook, sold by Apple Inc.\r\n10GB RAM, 500GB Hard Disk\r\nCore i7\r\n3ghz processor', '100000'),
('macbook pro', 'image/1(2).jpg', 'the generic macbook, sold by Apple Inc.\r\n10GB RAM, 500GB Hard Disk\r\nCore i7\r\n3ghz processor', '100000'),
('Sumsang Galaxy J4', '', 'This is one of the best phones in our market today. grab yourself the market sweetness.\r\ninternal storage 64 gb\r\nran 4gb\r\ncamera 32mp', '9000'),
('Sumsang Galaxy J4', '', 'This is one of the best phones in our market today. grab yourself the market sweetness.\r\ninternal storage 64 gb\r\nran 4gb\r\ncamera 32mp', '9000');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `username` varchar(60) NOT NULL,
  `Fname` varchar(60) NOT NULL,
  `Lname` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` int(20) NOT NULL,
  `pass` varchar(60000) NOT NULL,
  `image` varchar(633) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`username`, `Fname`, `Lname`, `email`, `phone`, `pass`, `image`) VALUES
('', '', '', '', 0, '', ''),
('mikael', 'mike', 'jagoo', 'mjk@gmail.com', 79885626, '6512bd43d9caa6e02c990b0a82652dca', 'NULL'),
('kelvin', 'joo', 'loonh', 'jk@hj.om', 78994, '6512bd43d9caa6e02c990b0a82652dca', 'NULL'),
('youid', 'hoiu', 'jjks', 'nmj@hou.mk', 789945, '35f4a8d465e6e1edc05f3d8ab658c551', 'NULL'),
('mike', 'mikael', 'mikaol', 'mike@gmail.com', 797753625, '18126e7bd3f84b3f3e4df094def5b7de', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('', '', '', '', 0, 'd41d8cd98f00b204e9800998ecf8427e', 'NULL'),
('kkk', 'jdk', 'joel', 'mike@jkdk', 788, '', 'NULL'),
('uuuu', 'jkkk', 'yuh', 'sdfgh@3erfvb', 7885, '', 'NULL'),
('mikael', 'kasike', 'mike', 'mikaelkasike861@gmail.com', 797753625, '84dcd484d02ce383f781dd6804aac78e', 'NULL');

-- --------------------------------------------------------

--
-- Table structure for table `entertainment`
--

CREATE TABLE `entertainment` (
  `name` varchar(6000) NOT NULL,
  `image` varchar(6000) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `entertainment`
--

INSERT INTO `entertainment` (`name`, `image`, `description`, `price`) VALUES
('Samsung Tv', '', 'Clear images at your siting\r\n43\" LCD\r\nHD', '50,000'),
('Samsung Tv', '', 'Clear images at your siting\r\n43\" LCD\r\nHD', '50,000');

-- --------------------------------------------------------

--
-- Table structure for table `general`
--

CREATE TABLE `general` (
  `name` varchar(60) NOT NULL,
  `image` varchar(60) NOT NULL,
  `description` mediumtext NOT NULL,
  `price` int(25) NOT NULL,
  `quantity` int(25) NOT NULL,
  `category` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general`
--

INSERT INTO `general` (`name`, `image`, `description`, `price`, `quantity`, `category`) VALUES
('BMW motor', '‰PNG\r\n\Z\n\0\0\0\rIHDR\0\0ó\0\0õ\0\0\0m4€\0\0\0sRGB\0®Îé\0\0\0gAMA\0\0±ü', 'the best racing motorbike, enjoy superflous speeds', 2000000, 25, 'Automobile'),
('BMW motor', '‰PNG\r\n\Z\n\0\0\0\rIHDR\0\0ó\0\0õ\0\0\0m4€\0\0\0sRGB\0®Îé\0\0\0gAMA\0\0±ü', 'the best racing motorbike, enjoy superflous speeds', 2000000, 25, 'Automobile'),
('Bm', '', '', 0, 0, ''),
('IPHONE 8', 'image/iphone8.png', 'The best Iphoe in market.\r\n64 gb internal storage\r\n4 gb Ram\r\nClear 14mp camera\r\nsmart display ', 64000, 25, 'phones'),
('IPHONE 8', 'image/iphone8.png', 'The best Iphoe in market.\r\n64 gb internal storage\r\n4 gb Ram\r\nClear 14mp camera\r\nsmart display ', 64000, 25, 'phones'),
('motor', 'hoda', 'good bike for riding', 60000, 64, 'Automobile'),
('motor', 'hoda.png', 'good bike for riding', 60000, 64, 'Automobile'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 0, '48'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates'),
('iphone 8', 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', 35000, 48, 'Smartphone and Tablates');

-- --------------------------------------------------------

--
-- Table structure for table `smartphones and tablets`
--

CREATE TABLE `smartphones and tablets` (
  `name` varchar(600) NOT NULL,
  `image` varchar(600) NOT NULL,
  `description` longtext NOT NULL,
  `price` varchar(800) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `smartphones and tablets`
--

INSERT INTO `smartphones and tablets` (`name`, `image`, `description`, `price`) VALUES
('oppo 5', '', 'Oppo 5 is the best Oppo smartphones in our store\r\n5gb RAM\r\n34gb storage\r\n4G connectivity\r\n4000 mAph bettary', '90000'),
('oppo 5', '', 'Oppo 5 is the best Oppo smartphones in our store\r\n5gb RAM\r\n34gb storage\r\n4G connectivity\r\n4000 mAph bettary', '90000');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `username` varchar(60) NOT NULL,
  `names` varchar(600) NOT NULL,
  `email` varchar(600) NOT NULL,
  `phone` varchar(40) NOT NULL,
  `password` varchar(6000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`username`, `names`, `email`, `phone`, `password`) VALUES
('fridah', 'fridah', 'fridah@gmail.com', '900090', '60aa4e8df7dabe2f2946355566de436a'),
('mike', 'mikael kasike', 'mikaelkasike861@gmail.com', '0797753625', '84dcd484d02ce383f781dd6804aac78e');

-- --------------------------------------------------------

--
-- Table structure for table `supplier_goods`
--

CREATE TABLE `supplier_goods` (
  `name` varchar(600) NOT NULL,
  `amount` int(11) NOT NULL,
  `image` varchar(600) NOT NULL,
  `description` longtext NOT NULL,
  `price` mediumtext NOT NULL,
  `category` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supplier_goods`
--

INSERT INTO `supplier_goods` (`name`, `amount`, `image`, `description`, `price`, `category`) VALUES
('iphone 8', 48, 'iphone8.png', 'iphone8 is the best phone currently in our stores\r\n64gb Internal storage\r\n4gb RAM\r\nsmart display screen\r\nmusic playback\r\n34mp camera', '35000', 'Smartphone and Tablates');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `phone` (`phone`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

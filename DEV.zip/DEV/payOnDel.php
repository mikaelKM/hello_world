<?php 
header('Content_type:application/download');
header('content_disposition:attachment;filename="receipt.txt"');
header("content-length:".filesize("receipt.txt"));
?>

<?php include("header.php");?>
   <style>
    .table{
        border:0px;
        width:50%;
        position:center;
    }
    .img-responsive{
        width: 50px;
    height:50px;
   
    }
    th{
        font-family:times;
        color: blue;
    }
    h3{
        font-family: times;
        color: green;
        text-transform: uppercase;
    }
    </style>
<?php 
$name =$_SESSION["name"];
$image =$_SESSION["image"];
$description=$_SESSION["description"];
$price= $_SESSION["price"];
$mode = "Pay on delivery";
//$im = "image/".$image;


if (empty($_SESSION['username'])){
$errorMessage =  "you must log in first";
    echo "<div class='error'>$errorMessage</div>";
    include("loginfirst.php");
}else{

include("connection.php");
$ddd = $_SESSION['username'];

if (isset($_POST["payon"])){
$location = $_POST["location"];
$phone = $_POST["phone"];


}



$d=strtotime("+3 days");
$deliverytime = date("d-m-y h:i:sa", $d) ;

$sql1 = "SELECT * FROM `customers` WHERE username='$ddd'";
$result1 = $con->query($sql1);

if($result1){
$row = $result1->fetch_assoc();

$fname = $row['Fname'];
$lname = $row['Lname'];
$email = $row['email'];


$sql = "INSERT INTO `soldgoods` (`username`, `Fname`, `Lname`, `good`, `image`, `price`, `mode of payment`, `CustomerLocation`, `customer_contact`, `customer_email`, `delivery_time`) VALUES ('$ddd', '$fname', '$lname', '$name', '$image', '$price', '$mode', '$location', '$phone', '$email', '$deliverytime')";
$result2 = $con->query($sql);
}


echo '<body style="background: #eee";><center>'.'<fieldset>'.
    '<h3>FMK Sales LTD</h3>'.'<h3>P.O BOX 44-100200, NAIROBI</h3>
    <h3>TELPHONE 0797753625</h3>'.'<h3>NAME: '.$fname.' '.$lname.'</h3>'.
        '<h4>INVOICE<h4>'.
    '<div class="table-responsive">'.
        '<table class="table table-striped">'.
            '<tr>
                <th>#</th>
                <th>ITEM</th>
                <th>IMAGE</th>
                <th>DESCRIPTION</th>
                <th>PRICE</th>
                <th>PAYMENT</th>
                <th>LOCATION</th>
                 <th>VALID PHONE</th>
                 <th>TIME OF DELIVERY</th>
            </tr>'.    
            '<tr>'.
                '<th scope="row">1</th>'.
                '<td>'.$name.'</td>'.
                '<td><img class="img-responsive" src='.$image.'></td>'.
                '<td>'.$description.'</td>'.
                '<td> Ksh '.$price.'</td>'.
                '<td> PAY ON DELIVERY</td>'.
                '<td> '.$location.'</td>'.
                '<td> '.$phone.'</td>'.
                '<td> '.$deliverytime.'</td>'.
            

           '</tr>
       

</table>

</div>


</fieldset>';




$Fp=fopen("receipt.txt", "w");
$x=90;
$F="FMK SALES LMTD \nP.O BOX 44-100200, NAIROBI \nTEL 0797753625 \n<><><><><><><><><><><><><>\nNAME :".$fname.' '.$lname."\nITEM: ".$name."\n<><><><><><><><><><><><><>\nDESCRIPTION: ".$description."\n<><><><><><><><><><><><><>\nPRICE:Ksh ".$price."\nPAYMENT:".$mode."\nLOCATION:".$location."\nTIME OF DELIVERY:".$deliverytime."\nYOUR PHONE NUMBER:".$phone;
fwrite($Fp, $F);
fclose($Fp);
//$fs=fopen("w.txt", "r");
//fpassthru($fs);
//fclose($fs);
echo"</br><a href='receipt.txt'download><button type='button' class='btn btn-primary'>Print receipt</button></a>";



//<button type="button" class="btn btn-primary">Print receipt</button>
//</center>
//</body>';

//echo $name . $image . $description . $price . $category;
//}else{
////	echo "EROR ENCOUNTERED".$con->error;
}
//}

?>
<?php include("fmkfooter.php");?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
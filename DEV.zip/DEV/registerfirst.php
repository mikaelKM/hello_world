 <style>
@import url("styling.css");
  </style>
</head>
<body style="background:violet;">
  <div class="juu">
  	<h2>Register</h2>
  </div>

  <form class="formss" method="post" action="Through_db.php">
  	<div class="form-group">
  	  <label>Username</label>
  	  <input type="text" name="username"  placeholder="username" required>
	  </div>
	  <div class="form-group">
  	  <label>First Name</label>
  	  <input type="text" name="fname"  placeholder="First Name" required>
	  </div>
	  <div class="form-group">
  	  <label>Last Name</label>
  	  <input type="text" name="lname"  placeholder="Last Name" required>
  	</div>
  	<div class="form-group">
  	  <label>Email</label>
  	  <input type="email" name="email"  placeholder="example@email.com" required>
	  </div>
	  <div class="form-group">
  	  <label>Phone number</label>
  	  <input type="number" name="phone"  placeholder="" required>
  	</div>
  	<div class="form-group">
  	  <label>Password</label>
  	  <input type="password" name="password_1" required>
  	</div>
  	<div class="form-group">
  	  <label>Confirm password</label>
  	  <input type="password" name="password_2" required>
  	</div>
<!--  <div class="form-group">
      <div class="avatar"><lable>select your picture:</lable><input type="file" name="avatar" accept"image/*"></div>-->
  	  <button type="submit" class="btn btn-primary" name="reg_userr">Register</button>
  </div>
  	<p>
  		Already a member? <a href="loginfirst.php">Log in</a>
  	</p>
  </form>
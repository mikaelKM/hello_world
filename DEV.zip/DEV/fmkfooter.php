
<footer style="background: rgb(117, 56, 56);">
<address>
   <i> Fmk sales limited</i> <br>
   <i> P.o Box 1123, Nairobi.</i><br>
   <i> Email: fridahmikael@kev.fmk.com</i><br>
   <i> Tel: 0797753625</i>
</address>
<ul class='list-inline'>
                                        <li class='list-inline-item'>
                                            <a class='social-icon text-xs-center' target='_blank' href='#'>
                                                <i class='fa fa-facebook'></i>
                                            </a>
                                        </li>
                                        <li class='list-inline-item'>
                                            <a class='social-icon text-xs-center' target='_blank' href='#'>
                                                <i class='fa fa-twitter'></i>
                                            </a>
                                        </li>
                                        <li class='ist-inline-item'>
                                            <a class='social-icon text-xs-center' target='_blank' href='#'>
                                                <i class='fa fa-skype'></i>
                                            </a>
                                        </li>
                                        <li class='list-inline-item'>
                                            <a class='social-icon text-xs-center' target='_blank' href='#'>
                                                <i class='fa fa-google'></i>
                                            </a>
                                        </li>
                                    </ul>
<h5> &#169 mikael </h5>
</footer>
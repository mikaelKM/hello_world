<?php include("header.php");?>
   <style>
    .table{
        border:0px;
        width:50%;
        position:center;
    }
    .img-responsive{
        width: 50px;
    height:50px;
   
    }
    th{
        font-family:times;
        color: blue;
    }
    h3{
        font-family: times;
        color: green;
        text-transform: uppercase;
    }
    </style>
<?php 

//$name= $_SESSION["name"];


if (empty($_SESSION['username'])){
$errorMessage =  "you must log in first";
    echo "<div class='error'>$errorMessage</div>";
    include("loginfirst.php");
}else{

include("connection.php");
$ddd = $_SESSION['username'];

if(isset($_GET["buy"])){
$name= $_GET["buy"];

$_SESSION["name"] = $name;
}

$sql ="SELECT * FROM `general` WHERE name='$name'";
$result5 = $con->query($sql);


if ($result5->num_rows>0){

    echo '<body style="background: #eee";><center>'.'<fieldset>'.
    '<h3>FMK Sales LTD</h3>'.'<h3>P.O BOX 44-100200, NAIROBI</h3>
    <h3>TELPHONE 0797753625</h3>'.'<h3>NAME: '.$ddd.'</h3>'.
        '<h4>INVOICE<h4>'.
    '<div class="table-responsive">'.
        '<table class="table table-striped">'.
            '<tr>
                <th>#</th>
                <th>ITEM</th>
                <th>IMAGE</th>
                <th>DESCRIPTION</th>
                <th>PRICE</th>
            </tr>';

            while($row = $result5->fetch_assoc()) {
                 
                $image=$row['image']; 
                $description=$row['description'];
                $price=$row['price'];

                
$_SESSION["image"] = $image;
$_SESSION["description"] = $description;
 $_SESSION["price"] = $price;

                echo '<tr>'.
                '<th scope="row">1</th>'.
                '<td>'.$name.'</td>'.
                '<td><img class="img-responsive" src='.$image.'></td>'.
                '<td>'.$description.'</td>'.
                '<td> Ksh '.$price.'</td>'.
            

           '</tr>
       

</table>
</div>';
            }
            ?>
            <h3>Additional information </h3>
<form class="formss" action="payOnDel.php" method ="post">
<div class="form-group">
        <label>Enter your active phone number :</label>
        <input type="number" name="phone" required >
    </div>
    <div class="form-group">
                        <label>Select your location:</label>
                        <select class="" name="location">
                            <option value="Huruma">Huruma</option>
                            <option value="Pipeline">Pipeline</option>
                            <option value="Kasarani">Kasarani</option>
                            <option value="Thika">Thika</option>
                            <option value="Kawagware">kawagware</option>
                          <!--  <option value="other">Others</option>-->
                        </select>
                    </div>
                  
<marquee><h3>We offer free delivery to all the places on our site</h3></marquee>
<h3>Select mode of payment</h3>
<a href="mpesa.php?price=<?php $price; ?>" <button type="button" class="btn btn-primary">LIPA NA MPESA</button></a>
<button type="submit" class="btn btn-primary" name="payon">Pay On Delivery</button>

<br>
</form>
</fieldset>
</center>
</body>

<?php 

}
}
//}

?>


<?php include("fmkfooter.php");?>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<?php
include('connectIion.php');
//$sql="INSERT INTO `bus`(`Id`, `Name`, `From`, `To`, `Depature`, `Fare`, `Capacity`) VALUES (null,'$name','$From','$To','$Depature','$Fare','$Capacity')";

if(!empty($_POST['Tell'])==true && !empty($_POST['balance'])==true){
	$no=$_POST['Tell'];
$balance=$_POST['balance'];
$sql="SELECT * FROM mpesa WHERE Tell_no='".$no."'";

$result=$conn->query($sql);

if($result->num_rows>0){
//$row=$result->fetch_assoc();
$sql1="UPDATE `mpesa` SET `Amount`=$balance WHERE Tell_no='".$no."'";
$result1=$conn->query($sql1);	
if($result1 === TRUE){
echo"<script>alert('account 123 ".$no." deposited ksh=".$balance."');</script>";
include('addmpesa.php');	
}else{
	echo "failed to add";
	include('addmpesa.php');
}
}else{
	$sql2="INSERT INTO `mpesa`(`Tell_no`, `Amount`) VALUES ('$no',$balance)";
	$result=$conn->query($sql2);	
if($result===True){
echo"<script>alert('account ".$no." deposited ksh=".$balance."');</script>";
include('addmpesa.php');	
}else{
	echo "failed to add";
	include('addmpesa.php');
}
}
}
?>